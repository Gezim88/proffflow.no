export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Kun POST er støttet." });
  }

  const { jobDescription } = req.body || {};

  if (!jobDescription) {
    return res.status(400).json({ error: "Mangler jobbbeskrivelse." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({
      error: "OPENAI_API_KEY mangler. Legg den inn som Environment Variable i Vercel."
    });
  }

  try {
    const prompt = `
Du er en erfaren norsk håndverker.

Lag et profesjonelt tilbud basert på denne jobben:

${jobDescription}

Tilbudet skal inneholde:
- Overskrift
- Kort introduksjon
- Arbeidsbeskrivelse
- Materialer
- Estimert tidsbruk
- Prisestimat i NOK
- Forbehold
- Profesjonell avslutning

Viktig:
- Skriv på norsk.
- Ikke lov mer enn håndverkeren kan garantere.
- Gjør teksten klar til å sende til kunde.
`;

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        input: prompt
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(500).json({
        error: data.error?.message || "Feil fra OpenAI."
      });
    }

    const offer =
      data.output_text ||
      data.output?.[0]?.content?.[0]?.text ||
      "Kunne ikke lese AI-svaret.";

    return res.status(200).json({ offer });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
