import React, { useState } from "react";
import { Hammer, Sparkles, FileText, Copy, CheckCircle } from "lucide-react";
import "./style.css";

export default function App() {
  const [job, setJob] = useState("");
  const [offer, setOffer] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  async function generateOffer() {
    if (!job.trim()) {
      alert("Skriv inn en jobbbeskrivelse først.");
      return;
    }

    setLoading(true);
    setOffer("");

    try {
      const response = await fetch("/api/generate-offer", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ jobDescription: job })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Noe gikk galt.");
      }

      setOffer(data.offer);
    } catch (error) {
      setOffer("Feil: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  async function copyOffer() {
    await navigator.clipboard.writeText(offer);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  return (
    <main className="page">
      <section className="hero">
        <div className="logo">
          <Hammer size={28} />
          <span>ProffFlow</span>
        </div>

        <h1>AI-verktøyet for norske håndverkere</h1>
        <p>
          Lag profesjonelle tilbud på sekunder. Spar tid på papirarbeid og send
          ryddige tilbud til kundene dine.
        </p>
      </section>

      <section className="card">
        <div className="cardHeader">
          <Sparkles />
          <div>
            <h2>Lag tilbud</h2>
            <p>Beskriv jobben kort, så lager ProffFlow et tilbud.</p>
          </div>
        </div>

        <textarea
          value={job}
          onChange={(e) => setJob(e.target.value)}
          placeholder="Eksempel: Male stue på 40m2 inkludert tak, sparkle små hull og dekke gulv."
        />

        <button onClick={generateOffer} disabled={loading}>
          {loading ? "Lager tilbud..." : "Generer tilbud"}
        </button>
      </section>

      {offer && (
        <section className="card result">
          <div className="cardHeader rowBetween">
            <div className="offerTitle">
              <FileText />
              <h2>Ferdig tilbud</h2>
            </div>

            <button className="secondary" onClick={copyOffer}>
              {copied ? <CheckCircle size={18} /> : <Copy size={18} />}
              {copied ? "Kopiert" : "Kopier"}
            </button>
          </div>

          <pre>{offer}</pre>
        </section>
      )}
    </main>
  );
}
