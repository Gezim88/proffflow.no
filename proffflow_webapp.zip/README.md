# ProffFlow

AI-verktøyet for norske håndverkere.

## Hva denne versjonen gjør

- Brukeren skriver inn en jobbbeskrivelse
- Appen sender teksten til OpenAI
- Appen returnerer et profesjonelt tilbud på norsk
- Tilbudet kan kopieres og sendes til kunde

## Lokal kjøring

Installer Node.js først.

```bash
npm install
npm run dev
```

## Viktig for Vercel

Legg inn denne miljøvariabelen i Vercel:

```text
OPENAI_API_KEY=din_openai_api_key
```

## Deploy

1. Last opp prosjektet til GitHub
2. Koble GitHub-repo til Vercel
3. Legg inn OPENAI_API_KEY under Environment Variables
4. Deploy
5. Koble domenet proffflow.no til Vercel
